package com.michifinder.modelo

data class Gato(val nombre : String ,val nombreRaza: String,
                val desGato : String, val imgGato : Int)